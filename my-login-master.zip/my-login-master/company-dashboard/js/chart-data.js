var randomScalingFactor = function(){ return Math.round(Math.random()*1000 + 3)};
		


			
	var doughnutData = [
				{
					value: 60,
					color: "122a3f",
					highlight: "80ca0f",
					label: "Mechanics"
				},
				{
					value: 10,
					color: "#a0a0a0",
					highlight: "#999999",
					label: "other"
				},
				{
					value: 15,
					color:"#dfdfdf",
					highlight: "#cccccc",
					label: "Technology"
				},
				{
					value: 15,
					color: "#f7f7f7",
					highlight: "#eeeeee",
					label: "General Business"
				}
			];
			
